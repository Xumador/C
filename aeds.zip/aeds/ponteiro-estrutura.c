#include <stdio.h>

int main(){
    struct{
        float campoA;
        int campoB;
    }registro,*ponteiro;
    registro.campoA=1.2;
    registro.campoB=100;
    ponteiro=&registro;
    printf("%.2f %d\n",ponteiro->campoA,ponteiro->campoB);
}
#include <stdio.h> // TA ERRADO!

// Coloque a implementação da função aqui
double mediaT(float a, float b, float c, float d) {
  double media = (a + b + c + d) / 4;
  return media;
}
int main(void) {
  // Coloque o seu código aqui
  float a, b, c, d, media;
  scanf("%f %f %f %f", &a, &b, &c, &d);
  media = mediaT(a, b, c, d);
  if (media >= 90) {
    printf("média: %.2f, Conceito A!", media);
  } else {
    if (70 <= media && media < 90) {
      printf("média: %.2f, Conceito B!", media);
    } else {
      if (60 <= media && media < 70) {
        printf("média: %.2f, Conceito C.", media);
      } else {
        if (media < 60) {
          printf("média: %.2f, Conceito D.", media);
        }
      }
    }
  }
}
#include <math.h>
#include <stdio.h>

// Coloque a implementação da função dist aqui!
float dist(float i1, float j1, float i2, float j2)
{
    float dist;
    dist = sqrt((pow((i1 - i2), 2) + pow((j1 - j2), 2)));
    return dist;
}

int main(void)
{
    float i1, i2, j1, j2;
    scanf("%f %f %f %f", &i1, &j1, &i2, &j2);
    printf("A distancia de p=(%.2f,%.2f) e q=(%.2f,%.2f) é %.2f", i1, j1, i2, j2, dist(i1, j1, i2, j2));
    return 0;
}
#include <stdio.h>

double potencia(int base, int expo)
{
    double result = 1;
    for (int i = 0; i < expo; i++)
        result = result * base;
    return result;
}
int main()
{
    printf("%.2lf\n", potencia(4, 3));
}
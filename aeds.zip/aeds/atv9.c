#include <math.h>
#include <stdio.h>
#define PI 3.141592654

int fatorial(int a)
{
    int x, fact = 1;
    for (x = 1; x <= a; x++)
        fact = fact * x;
    return 0;
}
int main(void)
{
    // Coloque o seu código aqui
    int i = 2, n, aux, aux2 = 0, fat;
    float resultado, diferença, final=0;
    scanf("%d", &n);
    aux = n;
    aux = (aux * PI) / 180;
    resultado = cos(aux);
    while (i < 20)
    {
        fat = fatorial(i);
        diferença = (n ^ i) / fat;
        aux2 = aux2 + diferença;
        i += 2;
    }
    printf("cos(%d) - serie = %.2f\n", n, final);
}
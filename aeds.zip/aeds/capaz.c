#include <stdio.h>

int main()
{
    int f, i;
    for (i = 0; i < 6; i++)
    {
        f += (rand() % 100);
        printf("%d\n", f);
    }
}
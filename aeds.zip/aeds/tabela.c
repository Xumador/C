#include <stdio.h>

int main()
{
    struct
    {
        int num;
        char letra;
    } vetor[8];

    for (int i = 0; i < 8; i++)
    {
        vetor[i].num = (i + 1) * 5;
        vetor[i].letra = i + 65;
    }

    for (int i = 0; i < 8; i++)
    {
        printf("%4d %c\n", vetor[i].num, vetor[i].letra);
    }
}
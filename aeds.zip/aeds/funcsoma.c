#include <stdio.h>

int soma(int a, int b)
{
    int resultado = a + b;
    return resultado;
}
int main()
{
    int v1, v2, r;
    scanf("%d %d", &v1, &v2);
    r = soma(v1, v2);
    printf("%d + %d = %d\n", v1, v2, r);
    return 0;
}
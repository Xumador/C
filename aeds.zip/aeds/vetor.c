#include <stdio.h>

int main()
{
    int vetor[4];
    int conta;
    float media;
    float n1, n2, n3, n4;
    media = 6;
    printf("Digite as notas: ");
    scanf("%d %d %d %d", &n1, &n2, &n3, &n4);
    conta = 0;
    media = (n1 + n2 + n3 + n4) / 4;
    if (n1 > media)
    {
        conta++;
    }
    if (n2 > media)
    {
        conta++;
    }
    if (n3 > media)
    {
        conta++;
    }
    if (n4 > media)
    {
        conta++;
    }
    printf("%d notas foram acima da média\n",conta);
}
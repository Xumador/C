#include <stdio.h>
#include <stdbool.h>

int main (void){
    unsigned char A = 0x3E, B = 0x25;
    printf("%X\n", B << 3);

}
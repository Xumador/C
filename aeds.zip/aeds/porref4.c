#include <stdio.h>

int main()
{
    char vetor[14] = "XUMA DO AMASSA";
    char *p;
    p = vetor;
    printf("%c %c\n", vetor[2], *(p + 2));
}
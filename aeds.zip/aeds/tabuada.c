#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(){
    int numero, i, r;
    i = 1;
    r = 0;
    printf("Digite um número: ");
    scanf("%d", &numero);
    while(i <= 10){
        r = numero*i;
        printf("%d x %d = %d\n", numero, i, r);
        i++;
    }
}
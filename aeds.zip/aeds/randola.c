#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{
    int numero, palpite, i;
    i = 0;
    while (i == 0)
    {
        numero = rand() % 10;
        puts("\nAdvinhe o numero magico [0..9]");
        scanf("%d", &palpite);
        if (palpite == numero)
        {
            printf("\nACERTOU !, o numero é %d!!\n", numero);
            i++;
        }
        else
        {
            printf("\nErrou, o numero era %d!!\n", numero);
        }
    }
}
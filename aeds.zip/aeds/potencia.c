#include <stdio.h>

int main()
{
    int base, expo;
    double resultado = 1;

    scanf("%d %d", &base, &expo);
    for (int i = 0; i < expo; i++)
        resultado = resultado * base;
    printf("%d^%d = %.2lf\n", base, expo, resultado);
}
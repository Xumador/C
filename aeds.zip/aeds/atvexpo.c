#include <stdio.h>

double exp (double x, int n) {
// Coloque o código da função exp aqui
    double result,fat;
    fat=1;
    result=1;
    for(int i=n;i>0;i--){
        fat=fat*i;
        result=(n^i)/fat;
    }
}

int main(void) {
  for (double x = 0.0; x < 10.0; x+=.5)
    printf("e^{%.2lf} = %.8lf\n", x, exp(x, 20));
}
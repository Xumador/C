#include <stdio.h>

// Coloque a função delta aqui
float delta(int a,int b,int c){
    float del;
    del=(b*b)-(4*a*c);
    return del;
}

int main(void) {
  float a, b, c;
  scanf("%f %f %f", &a, &b, &c);
  printf("O delta da equação é %.2f\n", delta(a, b, c));
}
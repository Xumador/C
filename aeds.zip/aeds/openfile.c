#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *arquivo;
    char line[100];
    arquivo = fopen("teste.txt", "rt");
    if (arquivo == NULL)
    {
        puts("O arquivo não existe");
        exit(10);
    }
    else
        puts("Arquivo aberto");
        fgets(line,100,arquivo);
        puts(line);
    fclose(arquivo);
}
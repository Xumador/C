#include <stdio.h>

int main()
{
    float cent, far;
    far = 50;
    cent = 0;
    printf(" Farenheit|Centígrado\n");
    printf("----------+-----------\n");
    for (; far <= 150; far += 5)
    {
        cent = (5 * (far - 32)) / 9;
        printf("   %3.f    |   %3.2f   \n", far, cent);
    }
}
#include <stdio.h>

int main()
{
    int soma;
    float n[10];
    /*n[0] = 10;
    n[1] = 20;
    n[2] = 30;
    n[3] = 40;
    n[4] = 50;*/
    for (int i = 0; i < 10; i++)
    {
        n[i] = rand() % 10;
        while (n[i] != i)
        {
            n[i] = rand() % 10;
            printf("[%2.f] -> pos: %d\n", n[i], i);
        }
        printf("[%2.f] -> pos: %d\n", n[i], i);
        printf("\n");
    }
    return 0;
}
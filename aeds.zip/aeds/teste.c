#include <stdio.h>
#include <math.h>

int main(){
    double x,a;
    x=exp(3);
    scanf("%lf", &a);
    printf("%lf",x);
    printf("%lf",a);
}
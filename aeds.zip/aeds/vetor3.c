#include <stdio.h>
#define N 5

int main()
{
    int v[N];
    for (int i = 0; i < N; i++)
    {
        scanf("%d", &v[i]);
    }
    system("clear");
    for (int i = 0; i < N; i++)
    {
        printf("%d\n", v[i]);
    }
}
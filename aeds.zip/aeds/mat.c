#include <stdio.h>
#include <math.h>

int main (void){
    double d;
    d = sqrt(100);
        printf("d = %.2lf\n", d);
    d = sin(45);
        printf("d = %.2lf\n", d);
    d = pow(100, 2);
        printf("d = %.2lf\n", d);
    return 0;
}
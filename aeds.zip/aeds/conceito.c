#include <stdio.h>

char conceito(int n1, int n2, int n3, int n4)
{
    int media = (n1 + n2 + n3 + n4) / 4;
    if (media < 60)
        return 'D';
    if (media < 70)
        return 'C';
    if (media < 90)
        return 'B';
    return 'A';
}
int main(void)
{
    int a, b, c, d;
    char conc;
    printf("Digite as 4 notas: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);
    conc = conceito(a, b, c, d);
    printf("Seu conceito é: [%c]\n", conc);
}

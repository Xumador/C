#include <stdio.h>

int main()
{
    int x = 10;
    int *p1, *p2; // & passa o endereço da variavel / * escreve oq ta dentro do endereço
    p1 = &x;
    p2 = p1;
    printf("%p:[%d]\n", &x, x);
    printf("%p:[%p]\n", &p1, p1);
    printf("%p:[%p]\n", &p2, p2);
    printf("%p:[%d]\n", p1, *p1);
    printf("%p:[%d]\n", p2, *p2);
    return 0;
}